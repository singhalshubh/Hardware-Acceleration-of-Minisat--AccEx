#!/bin/bash
MSAT=./build/profile/bin/minisat
#$MSAT input/test.cnf
cp $MSATP ./tmp/
MSAT=./tmp/minisat

$MSAT input/test.cnf
gprof $MSAT gmon.out > test.cnf
