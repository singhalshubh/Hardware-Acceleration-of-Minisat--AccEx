#!/bin/bash
MSAT=./build/release/bin/minisat
#minisat input/test.cnf > test.txt
$MSAT input/test.cnf
